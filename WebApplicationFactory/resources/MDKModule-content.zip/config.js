var appSettings = {
    "DefaultAppLanguage": "en",
    "ApplicationDisplayName": ""
}